package com.assignment.exception;

public class Co2CalculatorException extends Exception {

	private static final long serialVersionUID = 1227442121082275863L;

	public Co2CalculatorException(String errorMessage) {
		super(errorMessage);
	}
	
}
